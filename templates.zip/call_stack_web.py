from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import os
import subprocess
import json
from call_stack_tracker import CallStackTracker, run_java_test

app = Flask(__name__)

# Database path
DB_PATH = "call_stack.db"

def ensure_database_exists():
    """Ensure the database exists and has the correct schema."""
    tracker = CallStackTracker(DB_PATH)
    tracker.close()
    return True

def get_db_connection():
    """Create a database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_all_methods():
    """Get all methods from the database."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    SELECT method_id, method_signature, return_type, class_name, package_name, line_number
    FROM methods
    ORDER BY package_name, class_name, method_signature
    ''')
    methods = cursor.fetchall()
    conn.close()
    return methods

def get_method_by_id(method_id):
    """Get a method by its ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    SELECT method_id, method_signature, return_type, class_name, package_name, line_number
    FROM methods
    WHERE method_id = ?
    ''', (method_id,))
    method = cursor.fetchone()
    conn.close()
    return method

def get_call_stack(method_id, depth=5):
    """Get the call stack for a method."""
    tracker = CallStackTracker(DB_PATH)
    try:
        call_stack = tracker.get_call_stack(method_id, depth)
        
        # Add method_id to each method in the call stack
        def add_method_ids(methods):
            for method in methods:
                # Get the method_id for this method
                method_signature = method['method']
                class_name = method['class']
                package_name = method['package']
                
                # Find the method_id in the database
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute('''
                SELECT method_id FROM methods 
                WHERE method_signature = ? AND class_name = ? AND package_name = ?
                ''', (method_signature, class_name, package_name))
                result = cursor.fetchone()
                conn.close()
                
                # Add the method_id to the method data
                if result:
                    method['method_id'] = result['method_id']
                else:
                    # If method not found, use a placeholder
                    method['method_id'] = 0
                
                # Recursively process nested calls
                if 'calls' in method and method['calls']:
                    add_method_ids(method['calls'])
        
        # Process the call stack to add method_ids
        add_method_ids(call_stack)
        
        return call_stack
    finally:
        tracker.close()

def get_method_id_by_signature(method_signature, class_name, package_name):
    """Get a method ID by its signature, class name, and package name."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    SELECT method_id FROM methods 
    WHERE method_signature = ? AND class_name = ? AND package_name = ?
    ''', (method_signature, class_name, package_name))
    result = cursor.fetchone()
    conn.close()
    return result['method_id'] if result else None

@app.route('/')
def index():
    """Display the home page with all methods."""
    methods = get_all_methods()
    return render_template('index.html', methods=methods)

@app.route('/method/<int:method_id>')
def method_detail(method_id):
    """Display the call stack for a specific method."""
    method = get_method_by_id(method_id)
    if not method:
        return "Method not found", 404
    
    call_stack = get_call_stack(method_id)
    return render_template('method_detail.html', method=method, call_stack=call_stack)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    """Upload and analyze a Java file."""
    if request.method == 'POST':
        if 'file' not in request.files:
            return "No file uploaded", 400
        
        file = request.files['file']
        if file.filename == '':
            return "No file selected", 400
        
        if not file.filename.endswith('.java'):
            return "File must be a Java file", 400
        
        # Save the file temporarily
        temp_path = os.path.join('temp', file.filename)
        os.makedirs('temp', exist_ok=True)
        file.save(temp_path)
        
        try:
            # Run java-test.py on the file
            method_data = run_java_test(temp_path)

            if not method_data:
                return "No method data found in the file", 400
            
            print(method_data)
            
            # Initialize the call stack tracker
            tracker = CallStackTracker(DB_PATH)
            
            try:
                # Process the method data and store it in the database
                # This will update existing methods and add new ones
                tracker.process_method_data(method_data)
            finally:
                tracker.close()
            
            # Redirect to the home page
            return redirect(url_for('index'))
        
        finally:
            # Clean up the temporary file
            if os.path.exists(temp_path):
                os.remove(temp_path)
    
    return render_template('upload.html')

@app.route('/api/method/<int:method_id>')
def api_method_detail(method_id):
    """API endpoint to get the call stack for a method."""
    method = get_method_by_id(method_id)
    if not method:
        return jsonify({"error": "Method not found"}), 404
    
    call_stack = get_call_stack(method_id)
    return jsonify(call_stack)

@app.route('/api/methods')
def api_methods():
    """API endpoint to get all methods."""
    methods = get_all_methods()
    return jsonify([dict(method) for method in methods])

def create_templates():
    """Create the HTML templates for the Flask application."""
    # Create base.html
    with open('templates/base.html', 'w') as f:
        f.write('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Call Stack Tracker{% endblock %}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .method-link {
            text-decoration: none;
            color: #0d6efd;
        }
        .method-link:hover {
            text-decoration: underline;
        }
        .call-stack {
            margin-left: 20px;
            border-left: 2px solid #dee2e6;
            padding-left: 10px;
        }
        .method-signature {
            font-family: monospace;
        }
        .package-name {
            color: #6c757d;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="{{ url_for('index') }}">Call Stack Tracker</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('index') }}">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('upload') }}">Upload Java File</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        {% block content %}{% endblock %}
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
        ''')

    # Create index.html
    with open('templates/index.html', 'w') as f:
        f.write('''
{% extends 'base.html' %}

{% block title %}All Methods - Call Stack Tracker{% endblock %}

{% block content %}
<h1>All Methods</h1>

<div class="mb-4">
    <a href="{{ url_for('upload') }}" class="btn btn-primary">Upload Java File</a>
</div>

<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Package</th>
                <th>Class</th>
                <th>Method</th>
                <th>Return Type</th>
                <th>Line</th>
            </tr>
        </thead>
        <tbody>
            {% for method in methods %}
            <tr>
                <td class="package-name">{{ method['package_name'] }}</td>
                <td>{{ method['class_name'] }}</td>
                <td>
                    <a href="{{ url_for('method_detail', method_id=method['method_id']) }}" class="method-link method-signature">
                        {{ method['method_signature'] }}
                    </a>
                </td>
                <td>{{ method['return_type'] }}</td>
                <td>{{ method['line_number'] if method['line_number'] != 0 else 'Unknown' }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
{% endblock %}
        ''')

    # Create method_detail.html
    with open('templates/method_detail.html', 'w') as f:
        f.write('''
{% extends 'base.html' %}

{% block title %}{{ method['class_name'] }}.{{ method['method_signature'] }} - Call Stack Tracker{% endblock %}

{% block content %}
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ url_for('index') }}">Home</a></li>
        <li class="breadcrumb-item active">{{ method['class_name'] }}.{{ method['method_signature'] }}</li>
    </ol>
</nav>

<h1>Method Details</h1>

<div class="card mb-4">
    <div class="card-header">
        <h2 class="method-signature">{{ method['method_signature'] }}</h2>
    </div>
    <div class="card-body">
        <p><strong>Return Type:</strong> {{ method['return_type'] }}</p>
        <p><strong>Class:</strong> {{ method['class_name'] }}</p>
        <p><strong>Package:</strong> <span class="package-name">{{ method['package_name'] }}</span></p>
        <p><strong>Line:</strong> {{ method['line_number'] if method['line_number'] != 0 else 'Unknown' }}</p>
    </div>
</div>

<h2>Call Stack</h2>
<div class="call-stack-container">
    {% for method in call_stack %}
        {% include 'method_call.html' %}
    {% endfor %}
</div>
{% endblock %}
        ''')

    # Create method_call.html (partial template for recursive rendering)
    with open('templates/method_call.html', 'w') as f:
        f.write('''
<div class="method-call mb-3">
    <div class="method-header">
        <h3 class="method-signature">
            {% if method.get('method_id') and method['method_id'] != 0 %}
            <a href="{{ url_for('method_detail', method_id=method['method_id']) }}" class="method-link">
                {{ method['class'] }}.{{ method['method'] }}
            </a>
            {% else %}
            <span class="method-link">
                {{ method['class'] }}.{{ method['method'] }}
            </span>
            {% endif %}
            <span class="badge bg-secondary">Line {{ method['line'] if method['line'] != 0 else 'Unknown' }}</span>
        </h3>
    </div>
    
    {% if method.get('calls') %}
    <div class="call-stack">
        {% for call in method['calls'] %}
            {% with method=call %}
                {% include 'method_call.html' %}
            {% endwith %}
        {% endfor %}
    </div>
    {% endif %}
</div>
        ''')

    # Create upload.html
    with open('templates/upload.html', 'w') as f:
        f.write('''
{% extends 'base.html' %}

{% block title %}Upload Java File - Call Stack Tracker{% endblock %}

{% block content %}
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ url_for('index') }}">Home</a></li>
        <li class="breadcrumb-item active">Upload Java File</li>
    </ol>
</nav>

<h1>Upload Java File</h1>

<div class="card">
    <div class="card-body">
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="file" class="form-label">Select Java File</label>
                <input type="file" class="form-control" id="file" name="file" accept=".java" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload and Analyze</button>
        </form>
    </div>
</div>
{% endblock %}
        ''')

if __name__ == '__main__':
    # Ensure the database exists
    ensure_database_exists()
    
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    
    # Create the templates
    create_templates()
    
    app.run(debug=True) 