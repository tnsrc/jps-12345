import javalang
import sys
import os
import json

def find_variable_types(tree):
    """
    Find all variable declarations and their types in the Java code.
    Returns a dictionary mapping variable names to their types.
    """
    variable_types = {}
    
    for path, node in tree:
        # Check for local variable declarations
        if isinstance(node, javalang.tree.LocalVariableDeclaration):
            for declarator in node.declarators:
                if hasattr(declarator, 'initializer') and isinstance(declarator.initializer, javalang.tree.ClassCreator):
                    # Get type from the class creator
                    var_type = declarator.initializer.type.name
                    var_name = declarator.name
                    variable_types[var_name] = var_type
                else:
                    # Get type from the declaration
                    var_type = node.type.name
                    var_name = declarator.name
                    variable_types[var_name] = var_type
                
        # Check for field declarations
        elif isinstance(node, javalang.tree.FieldDeclaration):
            var_type = node.type.name
            for declarator in node.declarators:
                var_name = declarator.name
                variable_types[var_name] = var_type
    
    return variable_types

def find_user_defined_methods(tree):
    """
    Find all user-defined methods in the Java code.
    Returns a set of method names.
    """
    user_methods = set()
    
    for path, node in tree:
        if isinstance(node, javalang.tree.MethodDeclaration):
            user_methods.add(node.name)
    
    return user_methods

def get_arg_str(arg):
    """
    Extract a readable string representation of an argument from the AST.
    """
    # Handle literal values
    if hasattr(arg, 'value'):
        if isinstance(arg.value, str):
            return f'"{arg.value}"'
        return str(arg.value)
    
    # Handle member references (variables)
    if hasattr(arg, 'member'):
        return str(arg.member)
    
    # Handle qualified references (e.g., object.method)
    if hasattr(arg, 'qualifier') and hasattr(arg, 'member'):
        if arg.qualifier:
            return f"{arg.qualifier}.{arg.member}"
        return str(arg.member)
    
    # Handle binary operations (e.g., a + b)
    if hasattr(arg, 'operator') and hasattr(arg, 'operandl') and hasattr(arg, 'operandr'):
        left = get_arg_str(arg.operandl)
        right = get_arg_str(arg.operandr)
        op = arg.operator
        return f"{left} {op} {right}"
    
    # Default case
    return str(arg)

def get_package_name(tree):
    """
    Extract the package name from the Java code.
    """
    for path, node in tree:
        if isinstance(node, javalang.tree.PackageDeclaration):
            return node.name
    return ""

def get_class_name(tree, method_node=None):
    """
    Extract the class name from the Java code.
    If method_node is provided, find the class that contains this method.
    """
    # If method_node is provided, find the class that contains this method
    if method_node:
        # Find the parent class declaration
        for path, node in tree:
            if isinstance(node, javalang.tree.ClassDeclaration):
                # Check if this class contains the method
                for _, child in node:
                    if child == method_node:
                        return node.name
    
    # Default: just return the first class name found
    for path, node in tree:
        if isinstance(node, javalang.tree.ClassDeclaration):
            return node.name
    
    return ""

def get_arg_type(arg):
    """
    Determine the Java type of an argument based on its value.
    """
    if hasattr(arg, 'type') and arg.type:
        return arg.type.name
    
    # If we have a value, infer the type
    if hasattr(arg, 'value'):
        value = arg.value
        if isinstance(value, bool):
            return "boolean"
        elif isinstance(value, int):
            return "int"
        elif isinstance(value, float):
            return "double"
        elif isinstance(value, str):
            return "String"
        elif value is None:
            return "Object"
    
    # Default to Object if we can't determine the type
    return "Object"

def get_all_classes(tree):
    """
    Extract all class declarations from the Java code.
    Returns a dictionary mapping class names to their AST nodes.
    """
    classes = {}
    for path, node in tree:
        if isinstance(node, javalang.tree.ClassDeclaration):
            classes[node.name] = node
    return classes

def get_class_for_method(tree, method_node):
    """
    Find the class that contains the given method node.
    """
    for path, node in tree:
        if isinstance(node, javalang.tree.ClassDeclaration):
            # Check if this class contains the method
            for _, child in node:
                if child == method_node:
                    return node.name
    return ""

def extract_method_calls(java_code):
    """
    Extract all method declarations, their parameters, and their calls from Java code.
    Returns a dictionary mapping method names to their parameters, call lists, and line numbers.
    """
    try:
        tree = javalang.parse.parse(java_code)
        methods = {}
        variable_types = find_variable_types(tree)
        user_methods = find_user_defined_methods(tree)
        package_name = get_package_name(tree)
        all_classes = get_all_classes(tree)
        
        # First pass: collect all variable declarations and their types
        for path, node in tree:
            if isinstance(node, javalang.tree.LocalVariableDeclaration):
                for declarator in node.declarators:
                    if hasattr(declarator, 'initializer') and isinstance(declarator.initializer, javalang.tree.ClassCreator):
                        var_name = declarator.name
                        var_type = declarator.initializer.type.name
                        variable_types[var_name] = var_type
        
        # Second pass: collect method declarations and their calls
        for path, node in tree:
            if isinstance(node, javalang.tree.MethodDeclaration):
                method_name = node.name
                line_number = node.position.line if hasattr(node, 'position') and node.position else "unknown"
                
                # Get return type
                return_type = node.return_type.name if hasattr(node, 'return_type') and node.return_type else "void"
                
                # Get exceptions
                exceptions = []
                if hasattr(node, 'throws') and node.throws:
                    for exception in node.throws:
                        exceptions.append(exception.name)
                
                # Extract parameters: list of (type, name)
                params = []
                for param in node.parameters:
                    param_type = param.type.name
                    param_name = param.name
                    params.append(f"{param_type} {param_name}")
                
                # Create method declaration string
                method_declaration = f"{method_name}({', '.join(params)})"
                
                # Get the class name for this method
                class_name = get_class_for_method(tree, node)
                
                # Create a unique key for the method that includes the class name
                method_key = f"{class_name}.{method_name}"
                
                methods[method_key] = {
                    "method": method_declaration,
                    "returnType": return_type,
                    "exceptions": exceptions,
                    "class": class_name,
                    "package": package_name,
                    "line": line_number,
                    "calls": []
                }
                
                # Process method body
                if node.body:
                    method_variables = variable_types.copy()
                    
                    # Find method calls within the method body
                    for sub_path, sub_node in node:
                        if isinstance(sub_node, javalang.tree.MethodInvocation):
                            # Get line number for the method call
                            call_line = sub_node.position.line if hasattr(sub_node, 'position') and sub_node.position else 0
                            
                            # Extract argument strings
                            arg_strs = []
                            if hasattr(sub_node, 'arguments') and sub_node.arguments:
                                for arg in sub_node.arguments:
                                    arg_strs.append(get_arg_str(arg))
                            args_formatted = ", ".join(arg_strs)
                            
                            # Process all method calls without filtering
                            if sub_node.qualifier:
                                if isinstance(sub_node.qualifier, str):
                                    call = f"{sub_node.qualifier}.{sub_node.member}({args_formatted})"
                                else:
                                    # Variable reference
                                    var_name = str(sub_node.qualifier)
                                    call = f"{var_name}.{sub_node.member}({args_formatted})"
                            else:
                                call = f"{sub_node.member}({args_formatted})"
                            
                            # Create declaration string for the called method
                            declaration = ""
                            if sub_node.qualifier:
                                var_name = str(sub_node.qualifier)
                                if isinstance(sub_node.qualifier, str):
                                    if var_name in method_variables:
                                        declaration = f"{method_variables[var_name]}.{sub_node.member}"
                                    else:
                                        # Use the actual class name from the qualifier
                                        declaration = f"{sub_node.qualifier}.{sub_node.member}"
                                else:
                                    if var_name in method_variables:
                                        declaration = f"{method_variables[var_name]}.{sub_node.member}"
                                    else:
                                        declaration = f"{str(sub_node.qualifier)}.{sub_node.member}"
                            else:
                                declaration = sub_node.member
                            
                            # Add parameter types and names to declaration
                            if hasattr(sub_node, 'arguments') and sub_node.arguments:
                                param_types = []
                                for i, arg in enumerate(sub_node.arguments):
                                    param_type = get_arg_type(arg)
                                    # Use a generic parameter name if we don't have the actual name
                                    param_name = f"param{i+1}"
                                    param_types.append(f"{param_type} {param_name}")
                                declaration += f"({', '.join(param_types)})"
                            else:
                                declaration += "()"
                            
                            # Store the method call with its line number
                            methods[method_key]["calls"].append({
                                "usage": call,
                                "declaration": declaration,
                                "line": call_line
                            })
                            
                        # Update variable types as we go
                        elif isinstance(sub_node, javalang.tree.LocalVariableDeclaration):
                            for declarator in sub_node.declarators:
                                if hasattr(declarator, 'initializer') and isinstance(declarator.initializer, javalang.tree.ClassCreator):
                                    var_name = declarator.name
                                    var_type = declarator.initializer.type.name
                                    method_variables[var_name] = var_type
        
        return methods
    except javalang.parser.JavaSyntaxError as e:
        print(f"Error parsing Java code: {e}")
        return {}

def print_json_output(methods):
    """
    Print the method information in JSON format.
    """
    if not methods:
        print("No methods found or error parsing Java code.")
        return

    # Convert methods dictionary to list format
    methods_list = []
    for method_name, method_info in methods.items():
        methods_list.append(method_info)
    
    # Print JSON output
    print(json.dumps(methods_list, indent=4))

def analyze_java_file(file_path):
    """
    Analyze a Java file and print its call stack in JSON format.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            java_code = file.read()
        
        methods = extract_method_calls(java_code)
        print(f"\nAnalyzing file: {os.path.basename(file_path)}")
        print_json_output(methods)
        
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"Error analyzing file: {e}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python java-test.py <path_to_java_file>")
        return
    
    java_file_path = sys.argv[1]
    analyze_java_file(java_file_path)

if __name__ == "__main__":
    main() 