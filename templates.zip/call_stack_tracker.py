import sqlite3
import json
import sys
import os
import subprocess
from typing import Dict, List, Tuple, Optional

class CallStackTracker:
    def __init__(self, db_path: str = "call_stack.db"):
        """Initialize the call stack tracker with a SQLite database."""
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.setup_database()
    
    def setup_database(self):
        """Create the necessary tables if they don't exist."""
        # Table for storing method declarations
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS methods (
            method_id INTEGER PRIMARY KEY AUTOINCREMENT,
            method_signature TEXT NOT NULL,
            return_type TEXT NOT NULL,
            class_name TEXT NOT NULL,
            package_name TEXT NOT NULL,
            line_number INTEGER,
            UNIQUE(method_signature, class_name, package_name)
        )
        ''')
        
        # Table for storing method call relationships
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS method_calls (
            call_id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id INTEGER NOT NULL,
            child_id INTEGER NOT NULL,
            call_line INTEGER,
            FOREIGN KEY (parent_id) REFERENCES methods (method_id),
            FOREIGN KEY (child_id) REFERENCES methods (method_id)
        )
        ''')
        
        self.conn.commit()
    
    def insert_method(self, method_data: Dict) -> int:
        """
        Insert a method into the database and return its ID.
        If the method already exists, return its existing ID.
        """
        method_signature = method_data["method"]
        return_type = method_data["returnType"]
        class_name = method_data["class"]
        package_name = method_data["package"]
        line_number = method_data.get("line", 0)
        
        # Check if the method already exists
        self.cursor.execute('''
        SELECT method_id FROM methods 
        WHERE method_signature = ? AND class_name = ? AND package_name = ?
        ''', (method_signature, class_name, package_name))
        
        result = self.cursor.fetchone()
        if result:
            return result[0]
        
        # Insert the new method
        self.cursor.execute('''
        INSERT INTO methods (method_signature, return_type, class_name, package_name, line_number)
        VALUES (?, ?, ?, ?, ?)
        ''', (method_signature, return_type, class_name, package_name, line_number))
        
        self.conn.commit()
        return self.cursor.lastrowid
    
    def insert_method_call(self, parent_id: int, child_data: Dict, call_line: int) -> int:
        """
        Insert a method call relationship into the database.
        Returns the ID of the child method.
        """
        # First, insert the child method if it doesn't exist
        child_id = self.insert_method(child_data)
        
        # Then, insert the call relationship
        self.cursor.execute('''
        INSERT INTO method_calls (parent_id, child_id, call_line)
        VALUES (?, ?, ?)
        ''', (parent_id, child_id, call_line))
        
        self.conn.commit()
        return child_id
    
    def process_method_data(self, method_data: List[Dict]):
        """Process the method data from java-test.py and store it in the database."""
        # First, insert all method declarations
        method_ids = {}
        for method in method_data:
            method_key = f"{method['class']}.{method['method']}"
            method_id = self.insert_method(method)
            method_ids[method_key] = method_id
        
        # Then, process all method calls
        for method in method_data:
            method_key = f"{method['class']}.{method['method']}"
            parent_id = method_ids[method_key]
            
            for call in method.get("calls", []):
                # Extract class and method name from the declaration
                declaration = call["declaration"]
                call_line = call["line"]
                parts = declaration.split(".")
                
                if len(parts) >= 2:
                    # Handle qualified names (e.g., "com.example.TestA.doSomething")
                    if len(parts) >= 3:
                        package_name = ".".join(parts[:-2])
                        class_name = parts[-2]
                        method_name = parts[-1].split("(")[0]
                    else:
                        # Handle unqualified names (e.g., "TestA.doSomething")
                        package_name = method["package"]  # Use the same package as the caller
                        class_name = parts[0]
                        method_name = parts[1].split("(")[0]
                    
                    # Create a method data object for the callee
                    child_data = {
                        "method": method_name + "(" + declaration.split("(")[1],
                        "returnType": "void",  # Default, we don't have this information
                        "class": class_name,
                        "package": package_name,
                        "line": call_line
                    }
                    
                    # Insert the method call relationship with the line number
                    self.insert_method_call(parent_id, child_data, call_line)
    
    def get_call_stack(self, method_id: int, depth: int = 5) -> List[Dict]:
        """
        Retrieve the call stack for a given method ID.
        Returns a list of method calls in the stack.
        """
        def get_calls(mid: int, current_depth: int) -> List[Dict]:
            if current_depth <= 0:
                return []
            
            # Get the method details
            self.cursor.execute('''
            SELECT method_signature, return_type, class_name, package_name, line_number
            FROM methods WHERE method_id = ?
            ''', (mid,))
            
            method_result = self.cursor.fetchone()
            if not method_result:
                return []
            
            method_signature, return_type, class_name, package_name, line_number = method_result
            
            # Get all calls made by this method
            self.cursor.execute('''
            SELECT m.method_id, m.method_signature, m.return_type, m.class_name, m.package_name, mc.call_line
            FROM method_calls mc
            JOIN methods m ON mc.child_id = m.method_id
            WHERE mc.parent_id = ?
            ''', (mid,))
            
            calls = []
            for call_result in self.cursor.fetchall():
                child_id, child_signature, child_return, child_class, child_package, call_line = call_result
                
                # Recursively get calls made by the child method
                child_calls = get_calls(child_id, current_depth - 1)
                
                calls.append({
                    "method": child_signature,
                    "returnType": child_return,
                    "class": child_class,
                    "package": child_package,
                    "line": call_line,
                    "calls": child_calls
                })
            
            return calls
        
        # Get the method details
        self.cursor.execute('''
        SELECT method_signature, return_type, class_name, package_name, line_number
        FROM methods WHERE method_id = ?
        ''', (method_id,))
        
        method_result = self.cursor.fetchone()
        if not method_result:
            return []
        
        method_signature, return_type, class_name, package_name, line_number = method_result
        
        # Get all calls made by this method
        calls = get_calls(method_id, depth)
        
        return [{
            "method": method_signature,
            "returnType": return_type,
            "class": class_name,
            "package": package_name,
            "line": line_number,
            "calls": calls
        }]
    
    def get_method_by_signature(self, method_signature: str, class_name: str, package_name: str) -> Optional[int]:
        """Find a method ID by its signature, class name, and package name."""
        self.cursor.execute('''
        SELECT method_id FROM methods 
        WHERE method_signature = ? AND class_name = ? AND package_name = ?
        ''', (method_signature, class_name, package_name))
        
        result = self.cursor.fetchone()
        return result[0] if result else None
    
    def close(self):
        """Close the database connection."""
        self.conn.close()

def run_java_test(java_file_path: str) -> List[Dict]:
    """Run java-test.py on the given Java file and return the output as a list of dictionaries."""
    try:
        result = subprocess.run(
            ["python", "java-test.py", java_file_path],
            capture_output=True,
            text=True,
            check=True
        )
        
        # Extract the JSON output
        output = result.stdout
        json_start = output.find("[")
        json_end = output.rfind("]") + 1
        
        if json_start >= 0 and json_end > json_start:
            json_str = output[json_start:json_end]
            return json.loads(json_str)
        else:
            print("Error: Could not find JSON output in java-test.py output")
            return []
    except subprocess.CalledProcessError as e:
        print(f"Error running java-test.py: {e}")
        print(f"STDOUT: {e.stdout}")
        print(f"STDERR: {e.stderr}")
        return []
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON output: {e}")
        return []

def main():
    if len(sys.argv) < 2:
        print("Usage: python call_stack_tracker.py <path_to_java_file>")
        return
    
    java_file_path = sys.argv[1]
    
    # Run java-test.py to get the method data
    method_data = run_java_test(java_file_path)
    
    if not method_data:
        print("No method data found. Exiting.")
        return
    
    # Initialize the call stack tracker
    tracker = CallStackTracker()
    
    try:
        # Process the method data and store it in the database
        tracker.process_method_data(method_data)
        
        # Print the call stacks for all methods
        print("\nCall Stacks:")
        print("============")
        
        for method in method_data:
            method_key = f"{method['class']}.{method['method']}"
            method_id = tracker.get_method_by_signature(
                method["method"],
                method["class"],
                method["package"]
            )
            
            if method_id:
                call_stack = tracker.get_call_stack(method_id)
                print_call_stack(call_stack)
    
    finally:
        tracker.close()

def print_call_stack(call_stack: List[Dict], indent: int = 0):
    """Print a call stack in a readable format."""
    for method in call_stack:
        indent_str = "  " * indent
        print(f"{indent_str}Method: {method['class']}.{method['method']} (line {method['line']})")
        
        if method.get("calls"):
            for call in method["calls"]:
                call_indent_str = "  " * (indent + 1)
                print(f"{call_indent_str}Calls: {call['class']}.{call['method']} (line {call['line']})")
                print_call_stack([call], indent + 2)

if __name__ == "__main__":
    main() 