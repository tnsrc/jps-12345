import javalang
import sys
import os

def find_variable_types(tree):
    """
    Find all variable declarations and their types in the Java code.
    Returns a dictionary mapping variable names to their types.
    """
    variable_types = {}
    
    for path, node in tree:
        # Check for local variable declarations
        if isinstance(node, javalang.tree.LocalVariableDeclaration):
            for declarator in node.declarators:
                if hasattr(declarator, 'initializer') and isinstance(declarator.initializer, javalang.tree.ClassCreator):
                    # Get type from the class creator
                    var_type = declarator.initializer.type.name
                    var_name = declarator.name
                    variable_types[var_name] = var_type
                    print(f"Found variable: {var_name} of type {var_type}")  # Debug print
                else:
                    # Get type from the declaration
                    var_type = node.type.name
                    var_name = declarator.name
                    variable_types[var_name] = var_type
                    print(f"Found variable: {var_name} of type {var_type}")  # Debug print
                
        # Check for field declarations
        elif isinstance(node, javalang.tree.FieldDeclaration):
            var_type = node.type.name
            for declarator in node.declarators:
                var_name = declarator.name
                variable_types[var_name] = var_type
                print(f"Found field: {var_name} of type {var_type}")  # Debug print
    
    return variable_types

def find_user_defined_methods(tree):
    """
    Find all user-defined methods in the Java code.
    Returns a set of method names.
    """
    user_methods = set()
    
    for path, node in tree:
        if isinstance(node, javalang.tree.MethodDeclaration):
            user_methods.add(node.name)
    
    return user_methods

def extract_method_calls(java_code):
    """
    Extract all method declarations and their calls from Java code.
    Returns a dictionary mapping method names to lists of method calls and line numbers.
    """
    try:
        tree = javalang.parse.parse(java_code)
        methods = {}
        variable_types = find_variable_types(tree)
        user_methods = find_user_defined_methods(tree)
        
        print(f"\nAll found variables: {variable_types}")  # Debug print
        print(f"User-defined methods: {user_methods}")  # Debug print
        
        # First pass: collect all variable declarations and their types
        for path, node in tree:
            if isinstance(node, javalang.tree.LocalVariableDeclaration):
                for declarator in node.declarators:
                    if hasattr(declarator, 'initializer') and isinstance(declarator.initializer, javalang.tree.ClassCreator):
                        var_name = declarator.name
                        var_type = declarator.initializer.type.name
                        variable_types[var_name] = var_type
                        print(f"Found local variable: {var_name} of type {var_type}")  # Debug print
        
        # Second pass: collect method declarations and their calls
        for path, node in tree:
            if isinstance(node, javalang.tree.MethodDeclaration):
                method_name = node.name
                line_number = node.position.line if hasattr(node, 'position') and node.position else "unknown"
                methods[method_name] = {"line": line_number, "calls": []}
                
                # Process method body
                if node.body:
                    method_variables = variable_types.copy()
                    print(f"\nProcessing method: {method_name}")  # Debug print
                    
                    # Find method calls within the method body
                    for sub_path, sub_node in node:
                        if isinstance(sub_node, javalang.tree.MethodInvocation):
                            print(f"Found method call: {sub_node}")  # Debug print
                            
                            # Process all method calls without filtering
                            if sub_node.qualifier:
                                var_name = str(sub_node.qualifier)
                                if isinstance(sub_node.qualifier, str):
                                    if var_name in method_variables:
                                        call = f"{method_variables[var_name]}.{sub_node.member}()"
                                    else: # Direct class reference
                                        call = f"{sub_node.qualifier}.{sub_node.member}()"
                                else:
                                    # Variable reference
                                    print(f"Processing method call with variable: {var_name}")  # Debug print
                                    print(f"Available variables: {method_variables}")  # Debug print
                                    if var_name in method_variables:
                                        call = f"{method_variables[var_name]}.{sub_node.member}()"
                                    else:
                                        call = f"{var_name}.{sub_node.member}()"
                            else:
                                call = f"{sub_node.member}()"
                            
                            methods[method_name]["calls"].append(call)
                            
                        # Update variable types as we go
                        elif isinstance(sub_node, javalang.tree.LocalVariableDeclaration):
                            for declarator in sub_node.declarators:
                                if hasattr(declarator, 'initializer') and isinstance(declarator.initializer, javalang.tree.ClassCreator):
                                    var_name = declarator.name
                                    var_type = declarator.initializer.type.name
                                    method_variables[var_name] = var_type
                                    print(f"Found local variable in method: {var_name} of type {var_type}")  # Debug print
        
        return methods
    except javalang.parser.JavaSyntaxError as e:
        print(f"Error parsing Java code: {e}")
        return {}

def print_call_stack(methods):
    """
    Print the call stack for each method in a readable format.
    """
    if not methods:
        print("No methods found or error parsing Java code.")
        return
    
    print("\nCall Stack Analysis:")
    print("===================")
    
    for method_name, method_info in methods.items():
        line_number = method_info["line"]
        calls = method_info["calls"]
        print(f"\nMethod: {method_name} {line_number}")
        if calls:
            for i, call in enumerate(calls, 1):
                print(f"  {i}. Calls: {call}")
        else:
            print("  No method calls found.")

def analyze_java_file(file_path):
    """
    Analyze a Java file and print its call stack.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            java_code = file.read()
        
        methods = extract_method_calls(java_code)
        print(f"\nAnalyzing file: {os.path.basename(file_path)}")
        print_call_stack(methods)
        
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"Error analyzing file: {e}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python java-test.py <path_to_java_file>")
        return
    
    java_file_path = sys.argv[1]
    analyze_java_file(java_file_path)

if __name__ == "__main__":
    main() 